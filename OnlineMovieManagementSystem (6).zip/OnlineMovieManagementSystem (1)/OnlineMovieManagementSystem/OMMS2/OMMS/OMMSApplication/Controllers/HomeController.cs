﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using OMMS.Models.Domain;
using OMMS.Repositories.Abstract;
using System.Security.Claims;

namespace OMMS.Controllers
{
    [ResponseCache(Location =ResponseCacheLocation.None,NoStore =true)]
    [Authorize]
    public class HomeController : Controller
    {
        private readonly IMovieService _movieService;

        public HomeController(IMovieService movieService)
        {
            _movieService = movieService;
        }

        public IActionResult Login()
        {
            return View();
        }
        public IActionResult Index(string term = "")
        {
            ViewData["SearchTerm"] = term;
            var movies = _movieService.List(term);
            return View(movies);
        }

        

        public IActionResult MovieDetail(int movieId)
        {
            var movie = _movieService.GetById(movieId);
            if (movie == null)
            {
                return NotFound();
            }
            return View(movie);
        }
        public IActionResult MovieDetailWatchlist(int movieId)
        {
            var movie = _movieService.GetById(movieId);
            if (movie == null)
            {
                return NotFound();
            }
            return View(movie);
        }
    }
}