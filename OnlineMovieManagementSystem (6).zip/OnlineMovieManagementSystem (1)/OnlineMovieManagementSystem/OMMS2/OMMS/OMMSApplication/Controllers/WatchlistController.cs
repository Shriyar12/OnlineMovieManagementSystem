﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OMMS.Models.Domain;
using OMMSApplication.Repositories.Abstract;

namespace OMMSApplication.Controllers
{
    [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]

    public class WatchlistController : Controller
    {
        private readonly IWatchlistService _watchlistService;
        private readonly UserManager<ApplicationUser> _userManager;

        public WatchlistController(IWatchlistService watchlistService, UserManager<ApplicationUser> userManager)
        {
            _watchlistService = watchlistService;
            _userManager = userManager;
        }

        [HttpPost]
        public async Task<IActionResult> AddToWatchlist(int movieId)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            bool success = await _watchlistService.AddToWatchlistAsync(user.Id, movieId);
            if (!success) return BadRequest("Could not add to watchlist.");

            return RedirectToAction("Index", "Watchlist");
        }

        [HttpPost]
        public async Task<IActionResult> RemoveFromWatchlist(int movieId)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            bool success = await _watchlistService.RemoveFromWatchlistAsync(user.Id, movieId);
            if (!success) return BadRequest("Could not remove from watchlist.");

            return RedirectToAction("Index", "Watchlist");
        }


        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Unauthorized();

            var watchlist = await _watchlistService.GetUserWatchlistAsync(user.Id);
            return View(watchlist);
        }
    }


}
