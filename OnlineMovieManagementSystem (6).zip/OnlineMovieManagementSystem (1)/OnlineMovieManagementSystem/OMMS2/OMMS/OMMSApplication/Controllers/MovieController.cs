﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using OMMS.Models.Domain;
using OMMS.Models.DTO;
using OMMS.Repositories.Abstract;

namespace OMMS.Controllers
{
    [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]

    [Authorize]
    public class MovieController : Controller
    {
        private readonly IMovieService _movieService;
        private readonly IFileService _fileService;

        public MovieController(IMovieService movieService, IFileService fileService)
        {
            _movieService = movieService;
            _fileService = fileService;
        }

        public IActionResult Add()
        {
            return View(new Movie());
        }

        [HttpPost]
        public IActionResult Add(Movie model)
        {
            if (!ModelState.IsValid)
                return View(model);

            if (model.ImageFile != null)
            {
                var fileResult = _fileService.SaveImage(model.ImageFile);
                if (fileResult.Item1 == 0)
                {
                    TempData["msg"] = "File could not be saved";
                    return View(model);
                }
                model.MovieImage = fileResult.Item2;
            }

            var result = _movieService.Add(model);
            if (result)
            {
                TempData["msg"] = "Added Successfully";
                return RedirectToAction(nameof(MovieList));
            }
            else
            {
                TempData["msg"] = "Error on server side";
                return RedirectToAction(nameof(MovieList));
            }
        }

        public IActionResult Edit(int id)
        {
            var model = _movieService.GetById(id);
            if (model == null)
            {
                return NotFound();
            }

            return View(model);
        }

        [HttpPost]
        public IActionResult Edit(Movie model)
        {
            if (!ModelState.IsValid)
                return View(model);

            if (model.ImageFile != null)
            {
                var fileResult = _fileService.SaveImage(model.ImageFile);
                if (fileResult.Item1 == 0)
                {
                    TempData["msg"] = "File could not be saved";
                    return View(model);
                }
                model.MovieImage = fileResult.Item2;
            }

            var result = _movieService.Update(model);
            if (result)
            {
                TempData["msg"] = "Updated Successfully";
                return RedirectToAction(nameof(MovieList));
            }
            else
            {
                TempData["msg"] = "Error on server side";
                return RedirectToAction(nameof(MovieList));
            }
        }

        public IActionResult MovieList()
        {
            var data = _movieService.List();
            return View(data);
        }

        public IActionResult Delete(int id)
        {
            var result = _movieService.Delete(id);
            if (!result)
            {
                return NotFound();
            }
            return RedirectToAction(nameof(MovieList));
        }
    }
}