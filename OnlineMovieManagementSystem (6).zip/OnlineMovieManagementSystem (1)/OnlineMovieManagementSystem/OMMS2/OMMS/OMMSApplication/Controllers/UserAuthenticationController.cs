﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using OMMS.Models.DTO;
using OMMS.Repositories.Abstract;

namespace OMMS.Controllers
{
   [ResponseCache(Location = ResponseCacheLocation.None, NoStore = true)]

    public class UserAuthenticationController : Controller
    {
        private IUserAuthenticationService authService;
        public UserAuthenticationController(IUserAuthenticationService authService)
        {
            this.authService = authService;
        }
        public async Task<IActionResult> Register()
        {
            var model = new RegistrationModel
            {
                Email = "admin@gmail.com",
                Username = "admin",
                Name = "Admin",
                Password = "Admin@123",
                PasswordConfirm = "Admin@123",
                Role = "Admin"
            };

            var result = await authService.RegisterAsync(model);
            return Ok(result.Message);
        }

        public IActionResult UserRegistration()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UserRegistration(RegistrationModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await this.authService.RegisterAsync(model);

            if (result.StatusCode == 1)
            {
                var loginModel = new LoginModel
                {
                    Username = model.Username,
                    Password = model.Password
                };

                var loginResult = await authService.LoginAsync(loginModel);
                if (loginResult.StatusCode == 1)
                {
                    return RedirectToAction("Index", "Home");
                }
            }

            TempData["msg"] = result.Message;
            return RedirectToAction(nameof(UserRegistration));
        }
        public async Task<IActionResult> Login()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            var result = await authService.LoginAsync(model);
            if (result.StatusCode == 1)
                return RedirectToAction("Index", "Home");
            else
            {
                TempData["msg"] = "Could not logged in..";
                return RedirectToAction(nameof(Login));
            }
        }

        public async Task<IActionResult> Logout()
        {
            await authService.LogoutAsync();
            return RedirectToAction(nameof(Login));
        }

        public IActionResult VerifyEmail()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> VerifyEmail(VerifyEmailViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var result = await authService.VerifyEmailServices(model);

            if (result.StatusCode == 1)
            {
                return RedirectToAction("ChangePassword", "UserAuthentication", new { username = result.Message });
            }
            else
            {
                ModelState.AddModelError("", result.Message);
                return View(model);
            }
        }

        public IActionResult ChangePassword(string userName)
        {
            if (string.IsNullOrEmpty(userName))
            {
                return RedirectToAction("VerifyEmail", "UserAuthetication");
            }
            return View(new ChangePasswordViewModel { Email = userName });
        }

        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var result = await authService.ChangePasswordAsync(model);
            if (result.StatusCode == 1)
            {
                return RedirectToAction("Login", "UserAuthentication");
            }
            else
            {
                ModelState.AddModelError("", result.Message);
                return View(model);
            }
        }
    }
}
