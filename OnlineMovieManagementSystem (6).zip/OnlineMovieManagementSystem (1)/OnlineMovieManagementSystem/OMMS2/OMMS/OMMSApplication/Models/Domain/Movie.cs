﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace OMMS.Models.Domain
{
    public class Movie
    {
        public int Id { get; set; }
        
        [Required]
        public string? Title { get; set; }
        [Required]
        public string? ReleaseYear { get; set; }
        public string? MovieImage { get; set; }  
        
        public string? LeadActor { get; set; }
        
        public string? Director { get; set; }
        
        [NotMapped]
        public IFormFile? ImageFile { get; set; }

        // Genre and Language stored as simple strings
        [Required]
        public string? Genre { get; set; }
        
        [Required]
        public string? Language { get; set; }

        [Required]
        [Display(Name = "Duration (HH:mm)")]
        //[DisplayFormat(DataFormatString = "{0:0.00", ApplyFormatInEditMode =true)]
        public double Duration { get; set; }
        
        [Required]
        [Display(Name = "Budget")]
        [DataType(DataType.Currency)]
        public decimal Budget { get; set; }
        public double? Rating { get; set; }

        public ICollection<ApplicationUser> UsersWatchlist { get; set; } = new List<ApplicationUser>();
        }
}
