﻿using Microsoft.AspNetCore.Identity;

namespace OMMS.Models.Domain
{
    public class ApplicationUser : IdentityUser
    {
        public string Name{ get; set; }
        public ICollection<Movie> Watchlist { get; set; } = new List<Movie>();
    }
}
