﻿using OMMS.Models.Domain;

namespace OMMS.Models.DTO
{
    public class MovieListVm
    {
        public List<Movie> Movies { get; set; }
    }
}
