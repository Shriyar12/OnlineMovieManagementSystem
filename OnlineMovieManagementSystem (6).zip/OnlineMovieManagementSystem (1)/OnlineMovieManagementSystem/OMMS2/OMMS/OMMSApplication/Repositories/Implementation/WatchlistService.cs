﻿using OMMS.Models.Domain;
using OMMSApplication.Repositories.Abstract;
using Microsoft.EntityFrameworkCore;

namespace OMMSApplication.Repositories.Implementation
{
    public class WatchlistService : IWatchlistService
    {
        private readonly DatabaseContext _context;

        public WatchlistService(DatabaseContext context)
        {
            _context = context;
        }

        public async Task<bool> AddToWatchlistAsync(string userId, int movieId)
        {
            var user = await _context.Users.Include(u => u.Watchlist).FirstOrDefaultAsync(u => u.Id == userId);
            var movie = await _context.Movie.FindAsync(movieId);

            if (user == null || movie == null) return false;
            if (!user.Watchlist.Contains(movie))
            {
                user.Watchlist.Add(movie);
                await _context.SaveChangesAsync();
            }
            return true;
        }

        public async Task<bool> RemoveFromWatchlistAsync(string userId, int movieId)
        {
            var user = await _context.Users.Include(u => u.Watchlist).FirstOrDefaultAsync(u => u.Id == userId);
            var movie = await _context.Movie.FindAsync(movieId);

            if (user == null || movie == null) return false;
            if (user.Watchlist.Contains(movie))
            {
                user.Watchlist.Remove(movie);
                await _context.SaveChangesAsync();
            }
            return true;
        }
        

        public async Task<List<Movie>> GetUserWatchlistAsync(string userId)
        {
            var user = await _context.Users.Include(u => u.Watchlist).FirstOrDefaultAsync(u => u.Id == userId);
            return user?.Watchlist.ToList() ?? new List<Movie>();
        }
    }

}
