﻿using OMMS.Models.Domain;
using OMMS.Models.DTO;
using OMMS.Repositories.Abstract;

namespace OMMS.Repositories.Implementation
{
    public class MovieService : IMovieService
    {
        private readonly DatabaseContext ctx;

        public MovieService(DatabaseContext ctx)
        {
            this.ctx = ctx;
        }

        public bool Add(Movie model)
        {
            try
            {
                ctx.Movie.Add(model);
                ctx.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Update(Movie model)
        {
            try
            {
                ctx.Movie.Update(model);
                ctx.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public bool Delete(int id)
        {
            try
            {
                var movie = this.GetById(id);
                if (movie == null)
                    return false;

                ctx.Movie.Remove(movie);
                ctx.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }

        public Movie GetById(int id)
        {
            return ctx.Movie.Find(id);
        }

        public List<Movie> List(string term = "")
        {
            var list = ctx.Movie.AsQueryable();

            if (!string.IsNullOrEmpty(term))
            {
                term = term.ToLower();
                list = list.Where(a =>
                    a.Title.ToLower().Contains(term) ||
                    a.ReleaseYear.ToString().Equals(term) ||
                    a.LeadActor.ToLower().Contains(term) ||
                    a.Director.ToLower().Contains(term) || 
                    a.Genre.ToLower().Contains(term) ||
                    a.Language.ToLower().Contains(term) ||
                    a.Rating.ToString().Contains(term));
            }

           

            return list.ToList();
        }
    }
}