﻿using OMMS.Models.Domain;
using OMMS.Models.DTO;

namespace OMMS.Repositories.Abstract
{
    public interface IMovieService
    {
        bool Add(Movie model);
        bool Update(Movie model);
        Movie GetById(int id);
        bool Delete(int id);
        List<Movie> List(string term = "");
    }
}
