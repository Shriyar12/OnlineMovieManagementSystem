﻿using OMMS.Models.Domain;

namespace OMMSApplication.Repositories.Abstract
{
    public interface IWatchlistService
    {
        Task<bool> AddToWatchlistAsync(string userId, int movieId);
        Task<List<Movie>> GetUserWatchlistAsync(string userId);

        Task<bool> RemoveFromWatchlistAsync(string userId, int movieId);
    }

}
