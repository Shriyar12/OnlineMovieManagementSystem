﻿using OMMS.Models.DTO;

namespace OMMS.Repositories.Abstract
{
    public interface IUserAuthenticationService
    {

        Task<Status> LoginAsync(LoginModel model);
        Task LogoutAsync();
        Task<Status> RegisterAsync(RegistrationModel model);
        Task<Status> VerifyEmailServices(VerifyEmailViewModel model);
        Task<Status> ChangePasswordAsync(ChangePasswordViewModel model);
    }
}
